#include "sensorless.h"
#include "config.h"
#include <math.h>
#include <stdlib.h>

/* q31 angle convention: one electrical revolution = 2^32 counts. */
#define Q31_PI_F         2147483648.0f

#ifndef SENSORLESS_ANGLE_OFFSET_DEG
#define SENSORLESS_ANGLE_OFFSET_DEG (-90)
#endif
#ifndef SENSORLESS_ANGLE_SIGN
#define SENSORLESS_ANGLE_SIGN (1)
#endif
#ifndef SENSORLESS_BEMF_THRESHOLD
#define SENSORLESS_BEMF_THRESHOLD 18
#endif
#ifndef SENSORLESS_VALID_COUNT
#define SENSORLESS_VALID_COUNT 12
#endif
#ifndef SENSORLESS_MIN_START_SAMPLES
#define SENSORLESS_MIN_START_SAMPLES 180
#endif
#ifndef SENSORLESS_START_STEP_Q31
/* Initial electrical speed: ~4 Hz at 8192 ADC updates/s. */
#define SENSORLESS_START_STEP_Q31 2097152L
#endif
#ifndef SENSORLESS_RAMP_STEP_Q31
/* Electrical acceleration per ADC update. */
#define SENSORLESS_RAMP_STEP_Q31 16384L
#endif
#ifndef SENSORLESS_MAX_STEP_Q31
/* ~35 Hz electrical at 8192 updates/s. */
#define SENSORLESS_MAX_STEP_Q31 18350080L
#endif
#ifndef SENSORLESS_HP_SHIFT
#define SENSORLESS_HP_SHIFT 5
#endif
#ifndef SENSORLESS_LP_SHIFT
#define SENSORLESS_LP_SHIFT 2
#endif

static uint16_t off_a, off_b, off_c;
static int32_t lp_a, lp_b, lp_c;
static int32_t base_a, base_b, base_c;
static int32_t hp_a, hp_b, hp_c;
static q31_t open_angle;
static int32_t open_step;
static q31_t bemf_angle;
static uint16_t level;
static uint16_t valid_count;
static uint32_t start_count;
static uint8_t running;
static uint8_t valid;

static q31_t wrap_q31(int64_t a)
{
    return (q31_t)(uint32_t)a;
}

static q31_t atan2_to_q31(float y, float x)
{
    float a = atan2f(y, x);
    return (q31_t)(a * (Q31_PI_F / (float)M_PI));
}

void sensorless_init(uint16_t a, uint16_t b, uint16_t c)
{
    off_a = a; off_b = b; off_c = c;
    lp_a = lp_b = lp_c = 0;
    base_a = base_b = base_c = 0;
    hp_a = hp_b = hp_c = 0;
    open_angle = 0;
    open_step = SENSORLESS_START_STEP_Q31;
    bemf_angle = 0;
    level = 0;
    valid_count = 0;
    start_count = 0;
    running = 0;
    valid = 0;
}

void sensorless_start(void)
{
    open_angle = 0;
    open_step = SENSORLESS_START_STEP_Q31;
    bemf_angle = 0;
    valid_count = 0;
    start_count = 0;
    level = 0;
    valid = 0;
    running = 1;
}

void sensorless_stop(void)
{
    running = 0;
    valid = 0;
    valid_count = 0;
    level = 0;
}

void sensorless_update(uint16_t adc_a, uint16_t adc_b, uint16_t adc_c)
{
    int32_t a = (int32_t)adc_a - (int32_t)off_a;
    int32_t b = (int32_t)adc_b - (int32_t)off_b;
    int32_t c = (int32_t)adc_c - (int32_t)off_c;
    int32_t va, vb, vc;
    int32_t alpha, beta;
    int32_t dalpha, dbeta;
    uint32_t mag;

    if (!running) return;

    /* Remove common-mode voltage. The three existing phase-voltage ADCs are
       sampled together by the regular ADC/DMA sequence. */
    {
        int32_t common = (a + b + c) / 3;
        a -= common; b -= common; c -= common;
    }

    /* Light LP then HP filtering. The HP component is used as the BEMF-vector
       signal because the raw phase node also contains the applied PWM voltage. */
    lp_a += (a - lp_a) >> SENSORLESS_LP_SHIFT;
    lp_b += (b - lp_b) >> SENSORLESS_LP_SHIFT;
    lp_c += (c - lp_c) >> SENSORLESS_LP_SHIFT;

    va = lp_a; vb = lp_b; vc = lp_c;
    base_a += (va - base_a) >> SENSORLESS_HP_SHIFT;
    base_b += (vb - base_b) >> SENSORLESS_HP_SHIFT;
    base_c += (vc - base_c) >> SENSORLESS_HP_SHIFT;
    hp_a = va - base_a;
    hp_b = vb - base_b;
    hp_c = vc - base_c;

    /* Clarke transform. */
    alpha = hp_a;
    beta = (hp_b - hp_c) * 577L / 1000L; /* 1/sqrt(3) */
    dalpha = alpha;
    dbeta = beta;

    mag = (uint32_t)(abs(dalpha) + abs(dbeta));
    if (mag > 65535U) mag = 65535U;
    level = (uint16_t)mag;

    /* Open-loop push-start ramp. The scooter may be pushed while this angle
       advances; no Hall signal is required. */
    if (start_count < 100000U) start_count++;
    open_angle = wrap_q31((int64_t)(uint32_t)open_angle + (uint32_t)open_step);
    if (open_step < SENSORLESS_MAX_STEP_Q31) {
        open_step += SENSORLESS_RAMP_STEP_Q31;
        if (open_step > SENSORLESS_MAX_STEP_Q31)
            open_step = SENSORLESS_MAX_STEP_Q31;
    }

    if (start_count >= SENSORLESS_MIN_START_SAMPLES && mag >= SENSORLESS_BEMF_THRESHOLD) {
        q31_t raw = atan2_to_q31((float)dbeta, (float)dalpha);
        int64_t corrected = (int64_t)raw +
            (int64_t)SENSORLESS_ANGLE_OFFSET_DEG * 11930465LL;
        if (SENSORLESS_ANGLE_SIGN < 0) corrected = -corrected;
        raw = wrap_q31(corrected);

        /* PLL-like smoothing in angle space. */
        int32_t err = (int32_t)(raw - bemf_angle);
        bemf_angle = wrap_q31((int64_t)(uint32_t)bemf_angle + (err >> 3));

        if (valid_count < SENSORLESS_VALID_COUNT) valid_count++;
        if (valid_count >= SENSORLESS_VALID_COUNT) valid = 1;
    }
}

q31_t sensorless_angle(void)
{
    return valid ? bemf_angle : open_angle;
}

uint8_t sensorless_valid(void)
{
    return valid;
}

uint16_t sensorless_bemf_level(void)
{
    return level;
}
