#ifndef SENSORLESS_H_
#define SENSORLESS_H_

#include <stdint.h>
#include "arm_math.h"

/* Experimental BEMF-vector sensorless estimator.
 * The existing SmartESC firmware is Hall based. This module uses the three
 * phase-voltage ADC channels already present on the M365 board, starts with
 * a low-current open-loop electrical-angle ramp, then hands angle estimation
 * to the BEMF vector once a valid signal is detected.
 */
void sensorless_init(uint16_t off_a, uint16_t off_b, uint16_t off_c);
void sensorless_start(void);
void sensorless_stop(void);
void sensorless_update(uint16_t adc_a, uint16_t adc_b, uint16_t adc_c);
q31_t sensorless_angle(void);
uint8_t sensorless_valid(void);
uint16_t sensorless_bemf_level(void);

#endif
