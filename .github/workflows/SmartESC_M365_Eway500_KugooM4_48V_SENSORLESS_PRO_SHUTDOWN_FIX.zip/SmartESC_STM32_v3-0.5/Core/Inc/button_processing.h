/*
 * m365
 *
 * Copyright (c) 2021 Francois Deslandes
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
#include <arm_math.h>
#include "main.h"
#ifndef BUTTON_PROCESSING_H_
#define BUTTON_PROCESSING_H_


#define DEV_PWR_ON                          0x66
#define DEV_PWR_OFF                         0xDD
#define DEV_PWR_RESTART                     0xBA


typedef enum {
    NO_PRESS,
    SINGLE_PRESS,
    LONG_PRESS,
    DOUBLE_PRESS,
	VERY_LONG_PRESS
} eButtonEvent ;

void checkButton(MotorParams_t *MP, MotorState_t *MS);
void PWR_init();
void poweroff(void);
int8_t check_power_button_pressed_state();
void power_control(uint8_t pwr);
void set_mode(MotorParams_t *MP, MotorState_t *MS);

#endif /* TASK_PWR_H_ */
