# Sensorless + M365 Pro dashboard + shutdown fix

This build is based on the supplied SmartESC v0.5 source.

## Changes
- `DISPLAY_TYPE_M365PRO` selects the existing M365 UART dashboard driver.
- The dashboard driver is therefore the same packet implementation already present in the source; compatibility with a particular Pro BLE/dashboard firmware revision is **not proven** without testing/sniffing that dashboard.
- The delayed shutdown counter was removed. A deliberate long press now calls the power-off routine directly.
- Direct-drive wheel calibration is set to 800 mm circumference and gear ratio 1.
- Existing experimental sensorless module remains enabled.

## Important
The upstream SmartESC v0.5 documentation states that the original M365 dashboard is the tested dashboard. Pro-dashboard compatibility is not guaranteed by source alone.

The sensorless controller is experimental. Test with the wheel lifted and low current first. Do not treat the resulting BIN as validated firmware.
