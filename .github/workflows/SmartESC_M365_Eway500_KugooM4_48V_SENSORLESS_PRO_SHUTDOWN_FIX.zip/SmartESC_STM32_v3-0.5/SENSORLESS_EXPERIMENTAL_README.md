# Experimental sensorless BEMF mode

This branch changes the SmartESC M365 firmware from Hall-based rotor-angle selection to an experimental phase-voltage/BEMF estimator.

Hardware basis already present in this project:
- STM32F103
- phase-voltage ADC inputs PA6, PA7, PB1
- regular ADC/DMA sequence channels 3/4/5 for phase A/B/C
- existing FOC accepts a q31 rotor angle

Behavior:
1. Hall EXTI processing is disabled in sensorless mode.
2. On PWM enable, the estimator starts with a low-current open-loop electrical-angle ramp.
3. The three phase-voltage ADC readings are common-mode reduced and filtered.
4. A BEMF-vector angle is calculated with atan2 and phase-shifted by SENSORLESS_ANGLE_OFFSET_DEG.
5. After a valid BEMF signal is present for several samples, that angle replaces the open-loop angle.

Important:
- This is experimental. It is NOT a proven sensorless FOC implementation for this exact motor/controller.
- The phase-voltage divider scaling and PWM-synchronous sampling have not been calibrated here.
- The default BEMF angle offset may need tuning on the actual E-Way 500/Kugoo M4 motor.
- Test with the wheel off the ground and conservative phase/battery-current limits first.
- A wrong rotor angle can produce high current and damage MOSFETs or the motor.
- No flashable BIN is included as a verified release; GitHub Actions is used to compile the branch.
